``cheroot._compat`` module
~~~~~~~~~~~~~~~~~~~~~~~~~~

.. automodule:: cheroot._compat
    :members:
    :undoc-members:
    :show-inheritance:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
